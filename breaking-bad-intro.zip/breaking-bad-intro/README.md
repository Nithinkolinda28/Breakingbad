# Breaking Bad Intro

A Pen created on CodePen.io. Original URL: [https://codepen.io/olivier3lanc/pen/ZEgPNjb](https://codepen.io/olivier3lanc/pen/ZEgPNjb).

An HTML5 responsive experiment of Breaking Bad serie intro. 

Made with
https://ita-design-system.github.io/bricss/
https://github.com/olivier3lanc/Scroll-Btween

Credits: https://www.sonypictures.com/tv/breakingbad

Fonts: AtticAntique, HeartBreakingBad, SFPro
